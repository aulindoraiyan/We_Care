let themeButton = document.getElementById("theme-button");
const toggleDarkMode = () => {

  document.body.classList.toggle("dark-mode");

}
themeButton.addEventListener("click", toggleDarkMode)


// Signatures //

const signNowButton = document.getElementById("sign-now-button");

let counter = 4; //for counting the amount of signatures


const addSignature = () => {

  var signed = document.querySelector(".signatures");
  let remove = document.getElementById("initial_count");

  signed.removeChild(signed.lastChild);

  // Write your code to manipulate the DOM here
  let nameInput = document.getElementById('name').value;
  let hometownInput = document.getElementById('hometown').value;


  let divElement = document.createElement('p');
  divElement.innerHTML = ("🖊️ " + nameInput + " from " + hometownInput + " supports this.");

  let count = document.createElement('p');
  count.innerHTML = ('🖊️ ' + counter + " people have signed this petition and support this cause.");


  signed.appendChild(divElement);
  signed.appendChild(count);

  counter = counter + 1;
  remove.remove();

}

signNowButton.addEventListener("click", addSignature );

const validateForm = () => {

  let containsErrors = false;
  var petitionInputs = document.getElementById("sign-petition").elements;

  let person = {
    name: petitionInputs[0].value // accesses and saves value of first input
  }

  // TODO: Loop through all inputs
  for (let i = 0; i < petitionInputs.length; i++) {
    if (petitionInputs[i].value.length < 2) {
      containsErrors = true;
      petitionInputs[i].classList.add('error');
    }
    else {
      petitionInputs[i].classList.remove('error');
    }
  }
  if (containsErrors == false) {
    addSignature();
    for (let i = 0; i < petitionInputs.length; i++) {
      petitionInputs[i].value = "";
      containsErrors = false;
    }
    toggleModal(person);
  }
}

const animation ={

  revealDistance: 150,
  initialOpacity: 0,
  transitionDelay: '2s',
  transitionProperty: 'all',
  transitionTimingFunction: 'ease'
  
};

const revealableContainers = document.querySelectorAll('.revealable');

function reveal() {

  for( let i =0; i < revealableContainers.length; i++){
    
    let windowHeight = window.innerHeight;
    
    let revealableContainer = revealableContainers[i];

    //calculate distance from top of viewport to top of element

    let topOfRevealableContainer = revealableContainer.getBoundingClientRect().top;
    //check if element is in view

    if(topOfRevealableContainer < windowHeight - animation.revealDistance){
      revealableContainer.classList.add('active');
    }else{
      revealableContainer.classList.remove('active');
    }
  }
}

window.addEventListener('load', reveal);
window.addEventListener('scroll', reveal);

function toggleModal(person) {
  const modal = document.querySelector('#thanks-modal');
  const modalContent = document.querySelector('#thanks-modal-content');
  let intervalId = setInterval(scaleImage, 500);
  modal.style.display = 'flex';
  modalContent.textContent = `Thank you so much ${person.name}!`;

  setTimeout(() => {
    modal.style.display = 'none';
    clearInterval(intervalId);
  }, 4000); // 4 seconds
}

let scaleFactor = 1;
const modalImage = document.querySelector("#modal-image");

function scaleImage() {
  if (scaleFactor === 1) {
    scaleFactor = 0.8;
  } else {
    scaleFactor = 1;
  }

  modalImage.style.transform = `scale(${scaleFactor})`;
}
